# Mavuduru Saketh Ram — Portfolio

## Files
- `index.html` — responsive portfolio website with animated hero text, reveal effects, projects, credentials, experience, and contact links.
- `Mavuduru_Saketh_Ram_Resume_2026.pdf` — attached ATS-friendly resume.

## Preview on a laptop
1. Extract the ZIP file.
2. Open the `saketh_portfolio` folder.
3. Double-click `index.html` (or right-click it and choose Chrome).

## Publish with GitHub Pages
1. Sign in to GitHub and create a new public repository named `sakethram-portfolio` (or another name you prefer).
2. Upload `index.html` and `Mavuduru_Saketh_Ram_Resume_2026.pdf` to the repository root.
3. Open **Settings → Pages**. Under **Build and deployment**, choose **Deploy from a branch**, select **main** and **/(root)**, then save.
4. Wait for GitHub Pages to publish and copy the live URL shown in Settings → Pages.

The website is not published yet. You must complete the GitHub Pages steps using your GitHub account to get a live URL.

## Before publishing
- Add GitHub repository/demo links for projects when ready.
- Add certificate scans only if you want downloadable copies; the current page links to the public TID record.
- Check that the public contact details are okay to display.
